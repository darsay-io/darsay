# Toy model

A synthetic fixture.
