# acme / Toy-3.5-7B-Instruct

> Archived model bundle `test--acme--toy-3.5-7b-instruct@aaaaaaaaaaaa` — schema v1.8.0, artifact type `model`.

| | |
|---|---|
| **Family** | testlm |
| **Publisher** | acme |
| **Version** | — |
| **Released** | 2026-01-01T00:00:00+00:00 |
| **Parameters** | 8 (float32) |
| **Architecture** | TestLMForCausalLM (testlm) |
| **Context length** | 128 |
| **License** | Apache License 2.0 |
| **Payload** | 7 files, 664 B |
| **Integrity** | verified-against-upstream (last check 2026-09-03T04:10:54+00:00) |

## Source & provenance

- Origin: [test:acme/Toy-3.5-7B-Instruct](https://test.invalid/acme/Toy-3.5-7B-Instruct) via test
- Pinned revision: `aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa` (ref `main`, last modified upstream 2026-01-01T00:00:00+00:00)
- Downloaded: 2026-09-03T04:10:54+00:00 by darsay v0.14.10 (Python 3.14.7)
- Signatures: none provided upstream
- Upstream popularity at archive time: 12 downloads/month, 3 likes
- Subset: kept 7 of 8 upstream files matching `model.safetensors` + sidecars (1 omitted — full upstream list in `manifest.json` `source.subset.full_files`)

## Licensing

- SPDX: `apache-2.0`
- Commercial use: yes · Redistribution: yes · Modification: yes · Attribution required: yes
- License text in bundle: `model/LICENSE`
- Trademark terms: Section 6: no trademark rights granted beyond what is needed to describe origin of the work.

## Model metadata

- Parameters: 8
- Layers 1 · hidden 8 · heads 2 (KV 2)
- Precision: float32 · Quantization: none · Shards: 1
- Tokenizer: PreTrainedTokenizer, vocab 16, chat template absent
- Languages (per model card): en, fr
- Training cutoff: not published

## Runtime

- Engines (from shipped formats): transformers
- Estimated minimum RAM/VRAM: 0.0 GB (estimate, weights x1.2)
- Tested hardware: not yet tested — `darsay run` records the first real run
- CPU inference: yes

## Validation

- Checksums: **PASS** at 2026-09-03T04:10:54+00:00 (7 files)
- Completeness: **complete**
- Smoke tests: tokenizer `not-run`, inference `not-run`
- Full report: [VERIFICATION.md](VERIFICATION.md) · history in `verification.json`

## Relationships

- Derived from: `acme/Toy-3.5-7B`, `acme/Toy-3.5-7B-FP8` — relation: **finetune**
- Known GGUF conversions (1): `acme/Toy-3.5-7B-Instruct-GGUF`
- Known quantizations at archive time: 1 repos (full list in manifest)
- Public finetunes at archive time: 2 · adapters: 0
- Ecosystem snapshot taken: 2026-01-01T00:00:00+00:00

## Archive record

- Archived: 2026-09-03T04:10:54+00:00 on `MACJT94XJFKQ9` (local-disk)
- Location: `/private/var/folders/tf/7cg6g4xd0f1611ks07x8w1r40000gn/T/tmp9twgy0nx/vault/test--acme--toy-3.5-7b-instruct/aaaaaaaaaaaa`
- Backups: none · Replicas: 0
- Trust level: unreviewed

## Inventory

Bundle hash (`sha256-of-sorted-sha256-lines`): `18f74b94c18b9b20ef83e13bd06e2ecc49f3dc7506d17fef8da732128926d022`

| File | Size | SHA-256 (first 16) | Upstream match |
|---|---|---|---|
| `model/LICENSE` | 19 B | `4037bd3dec2b7a4a…` | ✓ |
| `model/README.md` | 34 B | `b5dbdcff38d5718a…` | ✓ |
| `model/config.json` | 297 B | `a1464779491621cf…` | ✓ |
| `model/generation_config.json` | 54 B | `db21a9a560278514…` | ✓ |
| `model/model.safetensors` | 102 B | `895ce52b7340c7a1…` | ✓ |
| `model/tokenizer.json` | 50 B | `726284f6b81c468c…` | ✓ |
| `model/tokenizer_config.json` | 108 B | `6a4eb928057d1dbc…` | ✓ |

Full hashes (SHA-256, upstream LFS/git) are in `manifest.json`.

## Using this bundle

One command — builds (or reuses) a local env, then runs a prompt fully offline:

```bash
darsay run /private/var/folders/tf/7cg6g4xd0f1611ks07x8w1r40000gn/T/tmp9twgy0nx/vault/test--acme--toy-3.5-7b-instruct/aaaaaaaaaaaa "Say hello in one short sentence."
```

(`darsay hydrate` prepares the env without running; envs live outside the
bundle under the vault's `.runtime/` and are recorded in `hydration.json`.)

Or point any Hugging Face-compatible loader at the pristine payload directly:

```python
from transformers import AutoModelForCausalLM, AutoTokenizer

path = "/private/var/folders/tf/7cg6g4xd0f1611ks07x8w1r40000gn/T/tmp9twgy0nx/vault/test--acme--toy-3.5-7b-instruct/aaaaaaaaaaaa/model"
tokenizer = AutoTokenizer.from_pretrained(path)
model = AutoModelForCausalLM.from_pretrained(path, torch_dtype="auto")
```

## Reproduce & audit

```bash
# Re-verify this bundle against its manifest
darsay verify /private/var/folders/tf/7cg6g4xd0f1611ks07x8w1r40000gn/T/tmp9twgy0nx/vault/test--acme--toy-3.5-7b-instruct/aaaaaaaaaaaa

# Re-create an identical bundle from upstream (bit-for-bit payload)
darsay archive test:acme/Toy-3.5-7B-Instruct --revision aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
```

## Curation

### Historical significance

_Why this model matters._

### Derivation & alignment changes

_How this artifact differs from its base — finetune, quantization, merge,
alignment modifications (e.g. abliteration) — beyond what upstream tags say._

### Major capabilities

_What it was known to do well._

### Known limitations

_Where it fell short._

### Successor models

_What replaced it._

### Personal notes

_Anything else worth remembering._

---
_Generated by darsay from `manifest.json` (schema v1.8.0). Do not edit this file directly; edit `curation.md` or the manifest and run `darsay regen`._
