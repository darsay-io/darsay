# Verification report — test--acme--toy-3.5-7b-instruct@aaaaaaaaaaaa

- **Result:** PASS
- **Run at:** 2026-09-03T04:10:54+00:00
- **Run type:** initial-archive (run 1 recorded in verification.json)
- **Files checked:** 7
- **Bundle hash:** `18f74b94c18b9b20ef83e13bd06e2ecc49f3dc7506d17fef8da732128926d022`
- **Completeness:** complete
- **Upstream cross-check:** all files match upstream LFS/git checksums

---
Re-run with: `darsay verify /var/folders/tf/7cg6g4xd0f1611ks07x8w1r40000gn/T/tmp9twgy0nx/vault/test--acme--toy-3.5-7b-instruct/aaaaaaaaaaaa`
