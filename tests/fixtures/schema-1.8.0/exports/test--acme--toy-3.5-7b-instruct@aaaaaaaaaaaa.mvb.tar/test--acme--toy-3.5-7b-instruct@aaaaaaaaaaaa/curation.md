# Curation notes — test--acme--toy-3.5-7b-instruct@aaaaaaaaaaaa

_This is the curator's file: edit it freely. `darsay regen` folds it into
README.md; nothing here is machine-generated after this template._

## Historical significance

_Why this model matters._

## Derivation & alignment changes

_How this artifact differs from its base — finetune, quantization, merge,
alignment modifications (e.g. abliteration) — beyond what upstream tags say._

## Major capabilities

_What it was known to do well._

## Known limitations

_Where it fell short._

## Successor models

_What replaced it._

## Personal notes

_Anything else worth remembering._
